import { Component } from '@angular/core';

@Component({
  selector: 'lib-shared-components',
  imports: [],
  template: `
    <p>
      shared-components works!
    </p>
  `,
  styles: ``
})
export class SharedComponentsComponent {

}
